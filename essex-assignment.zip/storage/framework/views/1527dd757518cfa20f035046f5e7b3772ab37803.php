

<?php $__env->startSection('content'); ?>

    <h1>Employees</h1>
    <a href="<?php echo e(route('employee.create')); ?>" class="btn mt-2 btn-primary">Add Employee</a>
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <table class="table mt-4">
        <thead>
        <tr>
            <th scope="col">ID</th>
            <th scope="col">First name</th>
            <th scope="col">Last name</th>
            <th scope="col">Email</th>
            <th scope="col">phone</th>
            <th scope="col">company name</th>
            <th scope="col">Action</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th scope="row"><?php echo e($employee->id); ?></th>
                <td><?php echo e($employee->first_name); ?></td>
                <td><?php echo e($employee->last_name); ?></td>
                <td><?php echo e($employee->email); ?></td>

                <td><?php echo e($employee->phone); ?></td>
                <td><?php echo e(\App\Company::find($employee->company_id)->name); ?></td>
                <td>
                    <a class="btn btn-success" href="<?php echo e(route('employee.edit',['employee'=>$employee->id])); ?>">edit</a>
                    <form method="post" action="<?php echo e(route('employee.delete')); ?>">
                        <input type="hidden" name="id" value="<?php echo e($employee->id); ?>" value="id">
                        <?php echo csrf_field(); ?>
                        <button class="btn btn-danger">delete</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php echo $employees->render(); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\essex-assignment\resources\views/employee/index.blade.php ENDPATH**/ ?>