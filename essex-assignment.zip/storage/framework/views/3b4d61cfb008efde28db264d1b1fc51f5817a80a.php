

<?php $__env->startSection('content'); ?>

    <h1>Companies</h1>
    <a href="<?php echo e(route('company.create')); ?>" class="btn mt-2 btn-primary">Add Company</a>

    <table class="table mt-4">
        <thead>
        <tr>
            <th scope="col">ID</th>
            <th scope="col">Name</th>
            <th scope="col">Email</th>
            <th scope="col">Logo</th>
            <th scope="col">Website</th>
            <th scope="col">Action</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <th scope="row"><?php echo e($company->id); ?></th>
            <td><?php echo e($company->name); ?></td>
            <td><?php echo e($company->email); ?></td>
            <td>
                <img width="40" height="40" src="<?php echo e("/storage/uploads/".$company->logo_name); ?>">
            </td>
            <td><?php echo e($company->website); ?></td>
            <td>
                <a class="btn btn-success" href="<?php echo e(route('company.edit',['company'=>$company->id])); ?>">edit</a>
                <form method="post" action="<?php echo e(route('company.delete')); ?>">
                    <input type="hidden" name="id" value="<?php echo e($company->id); ?>" value="id">
                    <?php echo csrf_field(); ?>
                <button class="btn btn-danger">delete</button>
                </form>
            </td>
        </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <?php echo $companies->render(); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\essex-assignment\resources\views/company/index.blade.php ENDPATH**/ ?>